<!-- / get in touch-->
        <!--Site Footer-->
        <section id="footer">
            <div class="footer-contain">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-3 col-xs-12">
                            <div class="help_section">
                                <h3>Help</h3>
                                <ul class="list-unstyled">
                                    <li><a href="#">FAQs</a></li>
                                    <li><a href="#">Payment</a></li>
                                    <li><a href="#">Service</a></li>
                                    <li><a href="#">Report</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-sm-3 col-xs-12">
                            <div class="other_menu_section">
                                <h3>Dhakasetup.com</h3>
                                <ul class="list-unstyled">
                                    <li><a href="#">About</a></li>
                                    <li><a href="#">Career</a></li>
                                    <li><a href="#">Become Service partner</a></li>
                                    <li><a href="#">Contact</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-sm-3 col-xs-12">
                            <div class="social_section">
                                <h3>Social</h3>
                                <ul class="list-unstyled list-inline">
                                    <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                    <li><a href="#"><i class="fa fa-google plus" aria-hidden="true"></i></a></li>
                                    <li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-sm-3 col-xs-12">
                            <div class="company_info">
                                <h3>Contact</h3>
                                <ul>
                                    <li>Mirpur Dhaka - 1216</li>
                                    <li>Email: @dhakasetup.com</li>
                                    <li>Call: +880-1670-894117</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="bottom-footer">
                <p>all right reserved &copy;2017 copyright</p>
            </div>
        </section>
        <!-- / Site Footer-->
        <!-- jQuery -->
        <script type="text/javascript" src="js/jquery.min.js"></script>
        <script type="text/javascript" src="js/bootstrap.min.js"></script>
        <script type="text/javascript" src="owl-carousel/owl.carousel.min.js"></script>
        <script type="text/javascript" src="js/datepicker.js"></script>
        <script type="text/javascript" src="js/validator.min.js"></script>
        <script type="text/javascript" src="js/cookie.js"></script>
        <script type="text/javascript" src="js/script.js"></script>
<script>
    $(document).ready(function () {
        var add_running = true;
        $('#schedule').datepicker();
        $('.redirect').click(function (e) {
            e.prevenDefault();
            var address = $('.redirect').attr('href');
            window.location.href = address;
        });

        $('.subcategory-name').click(function (e) {
            e.preventDefault();
            var subcategory = $(this).text();
            var parentdiv = $(this).parent().parent().parent().parent().parent();
            var category = parentdiv.find('.category-name').text();
            $.ajax({
                type: 'POST',
                url: 'index-service.php',
                data: {
                    "service-subcategory": subcategory,
                    "service-category" : category
                },
                dataType: 'html',
                success: function (data) {
                    $('.right-panel').html(data);
                },
                error: function (XMLHttpRequest, status, error) {
                    $('.right-panel').html(data);
                }
            });
        });

        $('.category-name').click(function(e){
            if($(this).attr('aria-expanded') === "false"){
                $('li .panel-collapse').removeClass('in');
            }
        });
        $("body").on('click', '.add-cart', function (e){
            e.preventDefault();
            var count = parseInt($('.aa-cart-notify').text(),10);
            var product_count = count;
            var id = $(this).val();
            if(add_running == true){
                if(!($.cookie('item_on_cart') == null)){
                    var item = jQuery.parseJSON($.cookie('item_on_cart'));
                    var i;
                    product_count++;
                    $.each( item, function( key, value ) {
                        $.each(value, function(key1,value1){
                            if(value1 == id){
                                product_count = count;
                            }
                        });
		    });
                }
                
                else{
                    product_count=1;
                }
                $.ajax({
                    type: 'POST',
                    url: 'Ajaxcart.php',
                    data: {
                        "id": id
                    },
                    dataType: 'html',
                    beforeSend: function(){
                        add_running = false;
                    },
                    success: function (data) {
                        $('.aa-cartbox-summary>ul').append(data);
                        $('#empty').hide();
                    },
                    complete: function(XMLHttpRequest, status){
                        $('#place_button').show();
                        $('.aa-cart-notify').text(product_count);
                        add_running=true;
                    }
                });
            }
            else{
                //console.log("RUNNING");
            }
        });
        $(".aa-cartbox-summary").on('click', '.aa-remove-product', function (e){
            e.preventDefault();
            var product_count = parseInt($('.aa-cart-notify').text(),10);
            var id = $(this).attr('ref');
            $.ajax({
                type: 'POST',
                url: 'Ajaxcart.php',
                data: {
                    "remove_id": id
                },
                dataType: 'html'
            });
            if(product_count>0){
                product_count--;
            }
            $('.aa-cart-notify').text(product_count);
            $(this).parent().remove();
            if($(".aa-cartbox-summary ul li").size()<1){
                $('#place_button').hide();
                $('#empty').show();
            }
        });

        $('.add-to-cart').click(function (e) {
            e.preventDefault();
            if(add_running == true){
                var count = parseInt($('.aa-cart-notify').text(),10);
                var product_count = count;
                var id = $(this).val();
                if(!($.cookie('item_on_cart') == null)){
                    var item = jQuery.parseJSON($.cookie('item_on_cart'));
                    var i;
                    product_count++;
                    $.each( item, function( key, value ) {
                        $.each(value, function(key1,value1){
                            if(value1 == id){
                                product_count = count;
                            }
                        });
		    });
                }
                
                else{
                    product_count=1;
                }
                var quantity = $('.quantity').val();
                $.ajax({
                    type: 'POST',
                    url: 'Ajaxcart.php',
                    data: {
                        "id": id,
                        "quantity": quantity
                    },
                    dataType: 'html',
                    beforeSend: function () {
                        add_running = false;
                    },
                    success: function (data) {
                        $('.aa-cartbox-summary>ul').append(data);
                        $('#empty').hide();
                    },
                    complete: function(XMLHttpRequest, status){
                        $('#place_button').show();
                        $('.aa-cart-notify').text(product_count);
                        add_running = true;
                    }
                });
            }
        });

        $(".aa-cartbox-summary").on('click', '.cart-item', function (e){
            e.preventDefault();

        });
        
        $('.aa-cartbox-summary').click(function (e) {
            e.stopPropagation();
        });

        $(".index-default").click(function () {
            $.ajax({
                type: 'POST',
                url: 'index-service.php',
                data: {
                    "index-default": true
                },
                dataType: 'html',
                success: function (data) {
                    $('.right-panel').html(data);
                },
                error: function (XMLHttpRequest, status, error) {
                    $('.right-panel').html(data);
                }
            });
        });
        
        $('.remove').click(function (e){
            e.preventDefault();
            var product_count = parseInt($('.aa-cart-notify').text(),10);
            var id = $(this).attr('href');
            $.ajax({
                type: 'POST',
                url: 'Ajaxcart.php',
                data: {
                    "remove_id": id
                },
                dataType: 'html'
            });
            if(product_count>0){
                product_count--;
            }
            $('.aa-cart-notify').text(product_count);
            $(this).parent().parent().remove();
            $(".aa-cartbox-summary ul").find('#'+id).remove();
            if($(".aa-cartbox-summary ul li").size()<1){
                $('#place_button').hide();
                $('#empty').show();
            }

            if($('.cart-info table tbody tr').size()<3){
                $('.cart-info table tbody').hide();
                $('.gray').hide();
                $('#goback').show();
            }
        });

        $('.quantity').change(function () {
            var quantity = $(this).val();
            var id = $(this).attr('id');
            var totalCost = ($(this).parent().parent().find('#totalCost'));
            var price = $(this).parent().parent().find('#price').text();
            var cart= $('.aa-cartbox-summary').find('#'+id);
            $.ajax({
                type: 'POST',
                url: 'Ajaxcart.php',
                data: {
                    "update_id": id,
                    "quantity":quantity,
                    "price":price
                },
                dataType: 'html',
                success: function (data) {
                    totalCost.text(data);
                }
            });
        });

        $('#booknow').click(function (e) {
            var order = true;
            $.ajax({
                type: 'POST',
                url: 'Ajaxcart.php',
                data: {
                    "final_order": order
                },
                success: function (data) {
                    $('#cartModal .modal-body .mobile_number').html(data);
                    console.log(data);
                }
            });
        });
    });
</script>