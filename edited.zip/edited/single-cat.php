<?php

        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
        error_reporting(E_ALL);

        $item = array('1','2','3');

        setcookie('item',json_encode($item),time()+60);

        require_once 'includes/connection.php';

        if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['search_button'])){
            $search = $_POST['search'];
            $query = "SELECT * FROM services WHERE srvice LIKE '%".$search."%' ORDER BY `srv_sl` DESC LIMIT 6";
        }
        else{
            $query = "SELECT * FROM services ORDER BY `srv_sl` DESC LIMIT 6";
        }

        $data = $dbcon->query($query);
?>
    <?php
    require_once 'main-header-dhaka-setup.php';
?>
        <!-- service-section -->
        <div class="service-section">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h3 class="heading">Subcategory-1</h3>
                        <div id="service-slider">
                            <div class="item">
                                <div class="col-sm-4 flip-effect">
                                    <div class="front-content">
                                        <div class="service-image">
                                            <img src="images/service/service-01.jpg" alt="image-1" class="img-responsive">
                                        </div>
                                        <div class="service-details">
                                            <h3>Home Appliance</h3>
                                        </div>
                                    </div>
                                    <div class="serv-btns">
                                        <a href="single.php" class="btn btn-default">view details</a>
                                        <a href="#" class="btn btn-default">add to cart</a>
                                    </div>
                                </div>
                                <div class="col-sm-4 flip-effect">
                                    <div class="front-content">
                                        <div class="service-image">
                                            <img src="images/service/service-01.jpg" alt="image-1" class="img-responsive">
                                        </div>
                                        <div class="service-details">
                                            <h3>Home Appliance</h3>
                                        </div>
                                    </div>
                                    <div class="serv-btns">
                                        <a href="single.php" class="btn btn-default">view details</a>
                                        <a href="#" class="btn btn-default">add to cart</a>
                                    </div>
                                </div>
                                <div class="col-sm-4 flip-effect">
                                    <div class="front-content">
                                        <div class="service-image">
                                            <img src="images/service/service-01.jpg" alt="image-1" class="img-responsive">
                                        </div>
                                        <div class="service-details">
                                            <h3>Home Appliance</h3>
                                        </div>
                                    </div>
                                    <div class="serv-btns">
                                        <a href="single.php" class="btn btn-default">view details</a>
                                        <a href="#" class="btn btn-default">add to cart</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12 text-center">
                        <a href="#" class="btn btn-default">view all</a>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <h3 class="heading">Subcategory-2</h3>
                        <div id="service-slider">
                            <div class="item">
                                <div class="col-sm-4 flip-effect">
                                    <div class="front-content">
                                        <div class="service-image">
                                            <img src="images/service/service-01.jpg" alt="image-1" class="img-responsive">
                                        </div>
                                        <div class="service-details">
                                            <h3>Home Appliance</h3>
                                        </div>
                                    </div>
                                    <div class="serv-btns">
                                        <a href="#" class="btn btn-default">view details</a>
                                        <a href="#" class="btn btn-default">add to cart</a>
                                    </div>
                                </div>
                                <div class="col-sm-4 flip-effect">
                                    <div class="front-content">
                                        <div class="service-image">
                                            <img src="images/service/service-01.jpg" alt="image-1" class="img-responsive">
                                        </div>
                                        <div class="service-details">
                                            <h3>Home Appliance</h3>
                                        </div>
                                    </div>
                                    <div class="serv-btns">
                                        <a href="#" class="btn btn-default">view details</a>
                                        <a href="#" class="btn btn-default">add to cart</a>
                                    </div>
                                </div>
                                <div class="col-sm-4 flip-effect">
                                    <div class="front-content">
                                        <div class="service-image">
                                            <img src="images/service/service-01.jpg" alt="image-1" class="img-responsive">
                                        </div>
                                        <div class="service-details">
                                            <h3>Home Appliance</h3>
                                        </div>
                                    </div>
                                    <div class="serv-btns">
                                        <a href="#" class="btn btn-default">view details</a>
                                        <a href="#" class="btn btn-default">add to cart</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12 text-center">
                        <a href="#" class="btn btn-default">view all</a>
                    </div>
                </div>
            </div>
        </div>
        </div>
        <!-- / service-section -->

        <!-- pagination -->
        <div class="container">
            <div class="row">
                <div class="col-sm-12 text-center">
                    <nav aria-label="Page navigation example">
                        <ul class="pagination justify-content-center">
                            <li class="page-item disabled">
                                <a class="page-link" href="#" tabindex="-1">Previous</a>
                            </li>
                            <li class="page-item"><a class="page-link" href="#">1</a></li>
                            <li class="page-item"><a class="page-link" href="#">2</a></li>
                            <li class="page-item"><a class="page-link" href="#">3</a></li>
                            <li class="page-item">
                                <a class="page-link" href="#">Next</a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
        <!-- /pagination -->
        <?php 
        require_once'main-footer-dhaka-setup.php';
        ?>

            </body>

            </html>