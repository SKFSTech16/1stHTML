<?php

        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
        error_reporting(E_ALL);

        $item = array('1','2','3');

        setcookie('item',json_encode($item),time()+60);

        require_once 'includes/connection.php';

        if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['search_button'])){
            $search = $_POST['search'];
            $query = "SELECT * FROM services WHERE srvice LIKE '%".$search."%' ORDER BY `srv_sl` DESC LIMIT 6";
        }
        else{
            $query = "SELECT * FROM services ORDER BY `srv_sl` DESC LIMIT 6";
        }

        $data = $dbcon->query($query);
?>
    <?php
    require_once 'main-header-dhaka-setup.php';
?>
       
        <!-- ad section -->
                <div class="ad">
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-offset-2 col-sm-10">
                                <img src="images/top-bannner.jpg">
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /ad section -->
                
        <!-- cat-section -->

        <section class="cat-section">
            <div class="container">
                <div class="row">
                    <div class="col-sm-3">
                        <a href="single-cat.php">
                            <div class="category-image">
                                <img src="images/service/service-01.jpg" alt="image-1" class="img-responsive">
                            </div>
                            <div class="cat-details">
                                <h3>Home Appliance</h3>
                            </div>
                        </a>
                    </div>
                    <div class="col-sm-3">
                        <a href="single-cat.php">
                            <div class="category-image">
                                <img src="images/service/service-01.jpg" alt="image-1" class="img-responsive">
                            </div>
                            <div class="cat-details">
                                <h3>Home Appliance</h3>
                            </div>
                        </a>
                    </div>
                    <div class="col-sm-3">
                        <a href="single-cat.php">
                            <div class="category-image">
                                <img src="images/service/service-01.jpg" alt="image-1" class="img-responsive">
                            </div>
                            <div class="cat-details">
                                <h3>Home Appliance</h3>
                            </div>
                        </a>
                    </div>
                    <div class="col-sm-3">
                        <a href="single-cat.php">
                            <div class="category-image">
                                <img src="images/service/service-01.jpg" alt="image-1" class="img-responsive">
                            </div>
                            <div class="cat-details">
                                <h3>Home Appliance</h3>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-3">
                        <a href="single-cat.php">
                            <div class="category-image">
                                <img src="images/service/service-01.jpg" alt="image-1" class="img-responsive">
                            </div>
                            <div class="cat-details">
                                <h3>Home Appliance</h3>
                            </div>
                        </a>
                    </div>
                    <div class="col-sm-3">
                        <a href="single-cat.php">
                            <div class="category-image">
                                <img src="images/service/service-01.jpg" alt="image-1" class="img-responsive">
                            </div>
                            <div class="cat-details">
                                <h3>Home Appliance</h3>
                            </div>
                        </a>
                    </div>
                    <div class="col-sm-3">
                        <a href="single-cat.php">
                            <div class="category-image">
                                <img src="images/service/service-01.jpg" alt="image-1" class="img-responsive">
                            </div>
                            <div class="cat-details">
                                <h3>Home Appliance</h3>
                            </div>
                        </a>
                    </div>
                    <div class="col-sm-3">
                        <a href="single-cat.php">
                            <div class="category-image">
                                <img src="images/service/service-01.jpg" alt="image-1" class="img-responsive">
                            </div>
                            <div class="cat-details">
                                <h3>Home Appliance</h3>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </section>
        <!-- / cat-section -->

        <!-- pagination -->
        <div class="container">
            <div class="row">
                <div class="col-sm-12 text-center">
                    <nav aria-label="Page navigation example">
                        <ul class="pagination justify-content-center">
                            <li class="page-item disabled">
                                <a class="page-link" href="#" tabindex="-1">Previous</a>
                            </li>
                            <li class="page-item"><a class="page-link" href="#">1</a></li>
                            <li class="page-item"><a class="page-link" href="#">2</a></li>
                            <li class="page-item"><a class="page-link" href="#">3</a></li>
                            <li class="page-item">
                                <a class="page-link" href="#">Next</a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
        <!-- /pagination -->
        <?php 
        require_once'main-footer-dhaka-setup.php';
        ?>

            </body>

            </html>